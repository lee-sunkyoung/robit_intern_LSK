#include <chrono>
#include <functional>

#include <pkg_example/pkg_example.hpp>


namespace pkg_example {


PkgExample::PkgExample() : Node("pkg_example") {

  this->setup();
}


void PkgExample::setup() {

  // subscriber for handling incoming messages
  subscriber_ = this->create_subscription<std_msgs::msg::Int32>("~/input", 10, std::bind(&PkgExample::topicCallback, this, std::placeholders::_1));
  RCLCPP_INFO(this->get_logger(), "Subscribed to '%s'", subscriber_->get_topic_name());

  // publisher for publishing outgoing messages
  publisher_ = this->create_publisher<std_msgs::msg::Int32>("~/output", 10);
  RCLCPP_INFO(this->get_logger(), "Publishing to '%s'", publisher_->get_topic_name());

  // timer for repeatedly invoking a callback
  timer_ = this->create_wall_timer(std::chrono::duration<double>(1.0), std::bind(&PkgExample::timerCallback, this));
}


void PkgExample::topicCallback(const std_msgs::msg::Int32::ConstSharedPtr& msg) {

  RCLCPP_INFO(this->get_logger(), "Message received: '%d'", msg->data);

  // publish message
  std_msgs::msg::Int32 out_msg;
  out_msg.data = msg->data;
  publisher_->publish(out_msg);
  RCLCPP_INFO(this->get_logger(), "Message published: '%d'", out_msg.data);
}


void PkgExample::timerCallback() {

  RCLCPP_INFO(this->get_logger(), "Timer triggered");
}


}


int main(int argc, char *argv[]) {

  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<pkg_example::PkgExample>());
  rclcpp::shutdown();

  return 0;
}
