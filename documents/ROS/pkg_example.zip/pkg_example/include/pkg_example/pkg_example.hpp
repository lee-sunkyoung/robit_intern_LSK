#pragma once

#include <memory>
#include <string>
#include <vector>

#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/int32.hpp>


namespace pkg_example {



/**
 * @brief PkgExample class
 */
class PkgExample : public rclcpp::Node {

 public:

  PkgExample();

 private:

  /**
   * @brief Sets up subscribers, publishers, etc. to configure the node
   */
  void setup();

  /**
   * @brief Processes messages received by a subscriber
   *
   * @param msg message
   */
  void topicCallback(const std_msgs::msg::Int32::ConstSharedPtr& msg);

  /**
   * @brief Processes timer triggers
   */
  void timerCallback();

 private:

  /**
   * @brief Subscriber
   */
  rclcpp::Subscription<std_msgs::msg::Int32>::SharedPtr subscriber_;

  /**
   * @brief Publisher
   */
  rclcpp::Publisher<std_msgs::msg::Int32>::SharedPtr publisher_;

  /**
   * @brief Timer
   */
  rclcpp::TimerBase::SharedPtr timer_;
};


}
